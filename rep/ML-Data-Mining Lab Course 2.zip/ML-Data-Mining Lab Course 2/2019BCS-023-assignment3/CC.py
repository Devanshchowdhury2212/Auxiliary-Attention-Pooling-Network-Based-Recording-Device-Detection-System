import math


class Fraction:
    def __init__(self, numerator: int, denominator: int):
        self.numerator = numerator
        self.denominator = denominator

    def __str__(self) -> str:
        return f"{self.numerator}/{self.denominator}"

    def __add__(self, other: "Fraction") -> "Fraction":
        lcm = math.lcm(self.denominator, other.denominator)
        factor1 = lcm // self.denominator
        factor2 = lcm // other.denominator
        return Fraction(self.numerator * factor1 + other.numerator * factor2, lcm)
