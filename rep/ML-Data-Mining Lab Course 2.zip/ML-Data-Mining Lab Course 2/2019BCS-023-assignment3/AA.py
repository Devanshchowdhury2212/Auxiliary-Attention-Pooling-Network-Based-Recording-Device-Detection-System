class Account:
    def __init__(self, type: str, holder: str, account_number: int):
        self.type = type
        self.holder = holder
        self.account_number = account_number
        self.__balance = 0

    def view_balance(self) -> int:
        return self.__balance

    def deposit(self, amount: int):
        self.__balance += amount

    def withdraw(self, amount: int):
        if self.__balance >= amount:
            self.__balance -= amount
        else:
            print("Insufficient funds")
