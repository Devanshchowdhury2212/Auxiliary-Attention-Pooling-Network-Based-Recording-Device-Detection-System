import math


class Location:
    def __init__(self, latitude: float, longitude: float):
        self.latitude = latitude
        self.longitude = longitude

    def __str__(self) -> str:
        return f"({self.latitude}, {self.longitude})"

    def distance_to(self, other: "Location") -> float:
        return math.dist((self.latitude, self.longitude), (other.latitude, other.longitude))
